"""
Example Notebook in Subsection
==============================

I actually generated this notebook instead of taking it off the shelf.

"""

a = [1, 2, 3]
for i in a:
    print(i)


######################################################################
# And some Math
# -------------
# 


######################################################################
# Offset:
# 
# .. math:: \frac{1}{N}\sum_{i=i}{N}x_i
# 
# And then in :math:`\frac{1}{N}\sum_{i=i}{N}x_i` a paragraph.
# 